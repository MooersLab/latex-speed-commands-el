## Description

Describe your changes in detail. What problem does this solve?

## Related issues

Closes #<issue-number>

## Type of change

- [ ] Bug fix (non-breaking change that fixes an issue)
- [ ] New feature (non-breaking change that adds functionality)
- [ ] Breaking change (fix or feature that would cause existing
      functionality to not work as expected)
- [ ] Documentation update

## Checklist

- [ ] I have read the [CONTRIBUTING](../CONTRIBUTING.md) guidelines.
- [ ] My code follows the code style of this project.
- [ ] I have added tests that prove my fix is effective or that my
      feature works.
- [ ] All new and existing tests pass (`make test`).
- [ ] Lint is clean (`make lint`) and coverage stays above 90%
      (`make coverage-check`).
- [ ] I have updated the documentation accordingly (`make texi docs-check`).
- [ ] I have added an entry to the Update Table in README.md.
