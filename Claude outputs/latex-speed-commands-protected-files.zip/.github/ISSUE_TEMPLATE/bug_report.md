---
name: Bug report
about: Report a bug to help us improve
title: "[BUG] "
labels: bug
assignees: ''
---

## Description

A clear and concise description of the bug.

## Steps to reproduce

1. Open a buffer with this LaTeX: '...'
2. Put point at '...'
3. Press '...'
4. See error

## Expected behavior

A clear and concise description of what you expected to happen.

## Actual behavior

A clear and concise description of what actually happened.  Paste the
backtrace from `M-x toggle-debug-on-error` if there is one.

## Environment

- OS: [e.g., macOS 14.2, Ubuntu 22.04]
- Emacs version: [e.g., Emacs 29.4, from M-x emacs-version]
- Major mode: [AUCTeX LaTeX-mode with version, or built-in latex-mode]
- latex-speed-commands version: [e.g., 0.1.0]

## Additional context

Add any other context about the problem here (screenshots, log output,
configuration).
