---
name: Feature request
about: Suggest an idea for this project
title: "[FEATURE] "
labels: enhancement
assignees: ''
---

## Problem description

A clear and concise description of the problem this feature would
solve. Example: "I find it frustrating when ..."

## Proposed solution

A clear and concise description of what you want to happen.  If you
propose a speed key, name the Org speed key that it mirrors.

## Alternatives considered

A clear and concise description of any alternative solutions or
features you have considered.

## Additional context

Add any other context or screenshots about the feature request here.
